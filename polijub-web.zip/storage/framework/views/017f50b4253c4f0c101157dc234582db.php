<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo e($title ?? 'Polijub Heladería'); ?></title>

<link rel="icon" href="<?php echo e(asset('images/ui/logo.webp')); ?>" type="image/webp">

<!-- Importación de Tailwind CSS -->
<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

<!-- Directivas de estilos de Livewire -->
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="bg-gray-100 font-sans antialiased" x-data="{ open: false }">
    <?php if (isset($component)) { $__componentOriginal8f2ea879bb839bb3b4f2f7b50b356091 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f2ea879bb839bb3b4f2f7b50b356091 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f2ea879bb839bb3b4f2f7b50b356091)): ?>
<?php $attributes = $__attributesOriginal8f2ea879bb839bb3b4f2f7b50b356091; ?>
<?php unset($__attributesOriginal8f2ea879bb839bb3b4f2f7b50b356091); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f2ea879bb839bb3b4f2f7b50b356091)): ?>
<?php $component = $__componentOriginal8f2ea879bb839bb3b4f2f7b50b356091; ?>
<?php unset($__componentOriginal8f2ea879bb839bb3b4f2f7b50b356091); ?>
<?php endif; ?>

    
    <?php echo e($slot); ?>


<!-- Directivas de scripts de Livewire -->
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


<!-- Importación de JavaScript de la aplicación -->
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>
</html><?php /**PATH C:\qb\innodesign\polijub-web\resources\views/layouts/app.blade.php ENDPATH**/ ?>