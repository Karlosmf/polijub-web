<div class="bg-brand-primary py-20">
    <div class="container mx-auto text-center text-white">
        <h2 class="text-4xl font-bold mb-5">POLINEWS</h2>
        <p class="mb-10">Suscribite a nuestro newsletter y enterate de todas las novedades y promociones.</p>
        <form class="join">
            <input class="input input-bordered join-item" placeholder="Email"/>
            <button class="btn btn-primary join-item rounded-r-full bg-brand-secondary">Suscribirme</button>
        </form>
    </div>
</div><?php /**PATH C:\qb\innodesign\polijub-web\resources\views/livewire/subscription-form.blade.php ENDPATH**/ ?>