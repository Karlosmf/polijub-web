<?php

namespace App\Livewire\Delivery;

use Livewire\Volt\Component;

class OrderForm extends Component
{
    public function render()
    {
        return view('livewire.delivery.order-form');
    }
}
