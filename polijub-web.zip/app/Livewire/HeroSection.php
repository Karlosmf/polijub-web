<?php

namespace App\Livewire;

use Livewire\Volt\Component;

class HeroSection extends Component
{
    public function render(): mixed
    {
        return view('livewire.hero-section');
    }
}
