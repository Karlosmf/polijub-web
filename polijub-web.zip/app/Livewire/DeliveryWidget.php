<?php

namespace App\Livewire;

use Livewire\Volt\Component;

class DeliveryWidget extends Component
{
    public function render(): mixed
    {
        return view('livewire.delivery-widget');
    }
}
