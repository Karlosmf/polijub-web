<?php

namespace App\Livewire;

use Livewire\Volt\Component;

class SubscriptionForm extends Component
{
    public function render(): mixed
    {
        return view('livewire.subscription-form');
    }
}
